This project is not currently taking public pull requests. 

If you have feedback, suggestions, or would like to help, please reach out in our tech support Discord server: https://discord.gg/KYqz993rRn

Or direct message MaikeruKonare#1043 and Maxbrand99#5913 on Discord.

Thanks!
